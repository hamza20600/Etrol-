
function addProduct() {
  const name = document.getElementById("name").value;
  const description = document.getElementById("description").value;
  const price = document.getElementById("price").value;
  const image = document.getElementById("image").value;
  const link = document.getElementById("link").value;

  alert("Product toegevoegd:\n" +
        "Naam: " + name + "\n" +
        "Beschrijving: " + description + "\n" +
        "Prijs: €" + price + "\n" +
        "Afbeelding: " + image + "\n" +
        "Link: " + link);

  return false; // voorkomen van pagina-herlaad
}
