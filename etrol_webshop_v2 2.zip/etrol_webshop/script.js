
const products = [
  {
    title: "Smartphone XYZ",
    description: "Krachtige smartphone met 128GB opslag.",
    price: "299.99",
    image: "https://via.placeholder.com/150",
    link: "https://partner.bol.com/click/click?p=1&t=url&s=dummysiteid&f=API&url=https%3A%2F%2Fwww.bol.com%2Fnl%2Fp%2Fsmartphone-xyz%2F&name=Smartphone+XYZ"
  },
  {
    title: "Laptop ABC",
    description: "Snel en lichtgewicht laptop voor dagelijks gebruik.",
    price: "599.99",
    image: "https://via.placeholder.com/150",
    link: "https://partner.bol.com/click/click?p=1&t=url&s=dummysiteid&f=API&url=https%3A%2F%2Fwww.bol.com%2Fnl%2Fp%2Flaptop-abc%2F&name=Laptop+ABC"
  }
];

const productList = document.getElementById("product-list");

products.forEach(product => {
  const productEl = document.createElement("div");
  productEl.className = "product";
  productEl.innerHTML = `
    <img src="${product.image}" alt="${product.title}">
    <h2>${product.title}</h2>
    <p>${product.description}</p>
    <p><strong>€${product.price}</strong></p>
    <a href="${product.link}" target="_blank">
      <button>Bekijk op bol.com</button>
    </a>
  `;
  productList.appendChild(productEl);
});
